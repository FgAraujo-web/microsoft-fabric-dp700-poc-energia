-- Exemplos de validações para a camada Silver
SELECT * FROM dbo.Fatura WHERE ValorTotal < 0;
SELECT F.* FROM dbo.Fatura F LEFT JOIN dbo.Cliente C ON C.ClienteID = F.ClienteID WHERE C.ClienteID IS NULL;
-- Nos pedidos, validar DataConclusao >= DataAbertura quando DataConclusao não for nula.
-- Nos consumos, validar QuantidadeKWh >= 0 e existência da UnidadeID.
