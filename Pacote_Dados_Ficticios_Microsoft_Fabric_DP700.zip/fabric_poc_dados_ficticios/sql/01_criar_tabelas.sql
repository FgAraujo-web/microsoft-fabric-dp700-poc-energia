-- Esquema de apoio à prova de conceito Microsoft Fabric DP-700
CREATE TABLE dbo.Cliente (
    ClienteID varchar(10) NOT NULL PRIMARY KEY,
    NomeCliente nvarchar(120) NOT NULL,
    Concelho nvarchar(60) NOT NULL,
    Segmento nvarchar(40) NOT NULL,
    DataAdesao date NOT NULL,
    EstadoCliente nvarchar(20) NOT NULL,
    UltimaAtualizacao datetime2 NOT NULL
);
CREATE TABLE dbo.UnidadeConsumo (
    UnidadeID varchar(12) NOT NULL PRIMARY KEY,
    ClienteID varchar(10) NOT NULL,
    TipoUnidade nvarchar(50) NOT NULL,
    Concelho nvarchar(60) NOT NULL,
    EstadoUnidade nvarchar(20) NOT NULL,
    DataAtivacao date NOT NULL,
    UltimaAtualizacao datetime2 NOT NULL
);
CREATE TABLE dbo.Fatura (
    FaturaID varchar(12) NOT NULL PRIMARY KEY,
    ClienteID varchar(10) NOT NULL,
    Periodo char(7) NOT NULL,
    DataEmissao date NOT NULL,
    DataVencimento date NOT NULL,
    ValorSemIVA decimal(12,2) NOT NULL,
    ValorIVA decimal(12,2) NOT NULL,
    ValorTotal decimal(12,2) NOT NULL,
    EstadoPagamento nvarchar(20) NOT NULL,
    DataPagamento date NULL,
    UltimaAtualizacao datetime2 NOT NULL
);
