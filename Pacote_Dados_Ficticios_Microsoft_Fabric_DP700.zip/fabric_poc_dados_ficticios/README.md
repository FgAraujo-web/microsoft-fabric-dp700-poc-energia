# Dados fictícios para prova de conceito Microsoft Fabric DP-700

Conjunto de dados totalmente sintético e determinístico (semente 7002026). Não contém informação real.

## Conteúdo

- `dados/carga_inicial`: clientes, unidades, consumos, pedidos e faturas.
- `dados/cargas_incrementais`: novos registos e alterações de setembro de 2026.
- `dados/tempo_real`: eventos JSON Lines para simular streaming.
- `sql`: esquema relacional e exemplos de validação.
- `Dicionario_Dados_Fabric.xlsx`: entidades, campos, regras, relações e anomalias conhecidas.

## Volumes da carga inicial

- Clientes: 500
- Unidades de consumo: 800
- Consumos: 19,201
- Pedidos: 10,001
- Faturas: 10,001

## Utilização sugerida

1. Carregar os ficheiros originais na camada Bronze sem os alterar.
2. Limpar, validar e deduplicar na camada Silver com SQL ou PySpark.
3. Construir dimensões e factos na camada Gold.
4. Usar `UltimaAtualizacao` ou `DataIngestao` como marca de água para cargas incrementais.
5. Encaminhar registos inválidos para uma tabela de quarentena.
6. Criar um modelo semântico e relatório em Power BI.

## Anomalias intencionais

O conjunto inclui duplicados, chaves inexistentes, valor de consumo negativo, total de fatura negativo, data inválida e pedido concluído antes da abertura. Consulte o dicionário para localizar e testar cada situação.

## Formato JSON Lines

Cada linha dos ficheiros `.jsonl` contém um objeto JSON independente. Este formato facilita ingestão batch e simulação de eventos.
